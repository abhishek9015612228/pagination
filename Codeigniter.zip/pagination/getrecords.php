<?php
require_once("config.php");
$limit 				= (intval($_GET['limit']) != 0 ) ? $_GET['limit'] : 10;
$offset 			= (intval($_GET['offset']) != 0 ) ? $_GET['offset'] : 0;

$sql 				= "SELECT countries_name FROM countries WHERE 1 ORDER BY countries_name ASC LIMIT $limit OFFSET $offset";
try {
  		$stmt 		= $DB->prepare($sql);
  		$stmt->execute();
  		$results 	= $stmt->fetchAll();
} catch (Exception $ex) {
  echo $ex->getMessage();
}
if (count($results) > 0) {
  foreach ($results as $res) {

    echo '<tr style="height:50px"><td>' . $res['countries_name'] . '</td><td>' . $res['countries_name'] . '</td><td>' . $res['countries_name'] . '</td></tr>';
  }
}
?>