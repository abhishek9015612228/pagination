<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


  </head>
  <body>
    <div class="container mainbody">
      <div class="page-header">
        <h1>Countries</h1>
      </div>
      <div class="clearfix"></div>
      <div class="margin10"></div>
      <div class="col-lg-12">
		<table class="table">
			<thead>
				<th>Country</th>
				<th>City</th>
				<th>Address</th>
				
			</thead>
			<tbody id="results">
       
		</tbody>
		</table>
        <div id="loader_image"><img src="loader.gif" alt="" width="24" height="24"> Loading...please wait</div>
        <div class="margin10"></div>
        <div id="loader_message"></div>

      </div>



      <div class="clearfix padding20"></div>
      
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script type="text/javascript">
      var busy = false;
      var limit = 15
      var offset = 0;

      function displayRecords(lim, off) {
        $.ajax({
          type: "GET",
          async: false,
          url: "getrecords.php",
          data: "limit=" + lim + "&offset=" + off,
          cache: false,
          beforeSend: function() {
            $("#loader_message").html("").hide();
            $('#loader_image').show();
          },
          success: function(html) {
            $("#results").append(html);
            $('#loader_image').hide();
            if (html == "") {
              $("#loader_message").html('<button class="btn btn-default" type="button">No more records.</button>').show()
            } else {
              $("#loader_message").html('<button class="btn btn-default" type="button">Loading please wait...</button>').show();
            }
            window.busy = false;


          }
        });
      }

      $(document).ready(function() {
        // start to load the first set of data
        if (busy == false) {
          busy = true;
          // start to load the first set of data
          displayRecords(limit, offset);
        }


        $(window).scroll(function() {
          if ($(window).scrollTop() + $(window).height() > $("#results").height() && !busy) {
            busy = true;
            offset = limit + offset;
            setTimeout(function() { displayRecords(limit, offset); }, 500);


          }
        });

      });

    </script>


  </body>
</html>
